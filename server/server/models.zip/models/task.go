package models

import (
	"encoding/json"
	"errors"
	"net/http"
	"sort"
	"strings"
	"time"

	runner "github.com/nerdynz/dat/sqlx-runner"
	"github.com/nerdynz/security"
)

var taskHelperGlobal *taskHelper

// Task Record
type Task struct {
	TaskID       int         `db:"task_id" json:"TaskID"`
	Description  string      `db:"description" json:"Description"`
	Status       string      `db:"status" json:"Status"`
	DateCreated  time.Time   `db:"date_created" json:"DateCreated"`
	DateModified time.Time   `db:"date_modified" json:"DateModified"`
	ULID         string      `db:"ulid" json:"ULID"`
	SiteID       int         `db:"site_id" json:"SiteID"`
	BoardID      int         `db:"board_id" json:"BoardID"`
	ReminderDate time.Time   `db:"reminder_date" json:"ReminderDate"`
	Actionables  Actionables `json:"Actionables"`
}

type Tasks []*Task

func (h *taskHelper) beforeSave(record *Task) (err error) {
	if record.DateCreated.IsZero() {
		record.DateCreated = time.Now()
	}
	record.DateModified = time.Now()
	if record.ULID == "" {
		record.ULID = security.ULID()
	}

	validationErr := h.validate(record)
	if validationErr != nil {
		return validationErr
	}
	return err
}

func (h *taskHelper) afterSave(record *Task) (err error) {
	return err
}

// GENERATED CODE - Leave the below code alone
type taskHelper struct {
	DB         *runner.DB
	Cache      Cache
	fieldNames []string
	orderBy    string
}

func TaskHelper() *taskHelper {
	if taskHelperGlobal == nil {
		taskHelperGlobal = newTaskHelper(modelDB, modelCache)
	}
	return taskHelperGlobal
}

func newTaskHelper(db *runner.DB, cache Cache) *taskHelper {
	helper := &taskHelper{}
	helper.DB = db
	helper.Cache = cache

	// Fields
	fieldnames := []string{"task_id", "description", "status", "date_created", "date_modified", "ulid", "site_id", "board_id", "reminder_date"}
	sort.Strings(fieldnames) // sort it makes searching it work correctly
	helper.fieldNames = fieldnames

	helper.orderBy = "date_created, date_modified"
	return helper
}

func (h *taskHelper) New(siteID int) *Task {
	record := &Task{}
	// check DateCreated
	record.DateCreated = time.Now()
	record.SiteID = siteID
	return record
}

func (h *taskHelper) FromRequest(siteID int, req *http.Request) (*Task, error) {
	record := h.New(siteID)
	contentType := req.Header.Get("Content-Type")
	if strings.Contains(contentType, "application/json") {
		// working with json
		decoder := json.NewDecoder(req.Body)
		err := decoder.Decode(record)
		if err != nil {
			return nil, err
		}
	} else {
		return nil, errors.New("Disabled - bring in h.structDecoder from gorilla")
		// // working with form values
		// err := req.ParseForm()
		// if err != nil {
		// 	return nil, err
		// }

		// err = h.structDecoder.Decode(record, req.PostForm)
		// if err != nil {
		// 	return nil, err
		// }
	}
	if record.SiteID != siteID {
		return nil, errors.New("*Task update failed. SiteID Mismatch")
	}
	record.SiteID = siteID
	return record, nil
}

func (h *taskHelper) Load(siteID int, id int) (*Task, error) {
	record, err := h.One(siteID, "task_id = $1", id)
	if err != nil {
		return nil, err
	}
	return record, nil
}

func (h *taskHelper) All(siteID int) (Tasks, error) {
	var records Tasks
	err := h.DB.Select("*").
		From("task").
		Where("site_id = $1", siteID).
		OrderBy(h.orderBy).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *taskHelper) Where(siteID int, sql string, args ...interface{}) (Tasks, error) {
	var records Tasks
	sql, args = appendSiteID(siteID, sql, args...)
	err := h.DB.Select("*").
		From("task").
		Where(sql, args...).
		OrderBy(h.orderBy).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *taskHelper) SQL(siteID int, sql string, args ...interface{}) (Tasks, error) {
	if !strings.Contains(sql, "$SITEID") {
		return nil, errors.New("No $SITEID placeholder defined")
	}
	var records Tasks
	sql, args = appendSiteID(siteID, sql, args...)
	err := h.DB.SQL(sql, args...).
		QueryStructs(&records)
	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *taskHelper) One(siteID int, sql string, args ...interface{}) (*Task, error) {
	var record Task
	sql, args = appendSiteID(siteID, sql, args...)

	err := h.DB.Select("*").
		From("task").
		Where(sql, args...).
		OrderBy(h.orderBy).
		Limit(1).
		QueryStruct(&record)

	if err != nil {
		return nil, err
	}

	return &record, nil
}

func (h *taskHelper) Paged(siteID int, pageNum int, itemsPerPage int) (*PagedData, error) {
	pd, err := h.PagedBy(siteID, pageNum, itemsPerPage, "date_created", "") // date_created should be the most consistant because it doesn't change
	if err != nil {
		return nil, err
	}
	return pd, nil
}

func (h *taskHelper) PagedBy(siteID int, pageNum int, itemsPerPage int, orderByFieldName string, direction string) (*PagedData, error) {
	if orderByFieldName == "" || orderByFieldName == "default" {
		// we only want the first field name
		orderByFieldName = strings.Split(h.orderBy, ",")[0]
		orderByFieldName = strings.Trim(orderByFieldName, " ")
	}
	i := sort.SearchStrings(h.fieldNames, orderByFieldName)
	// check the orderby exists within the fields as this could be an easy sql injection hole.
	if !(i < len(h.fieldNames) && h.fieldNames[i] == orderByFieldName) { // NOT
		return nil, errors.New("field name [" + orderByFieldName + "]  isn't a valid field name")
	}

	if !(direction == "asc" || direction == "desc" || direction == "") {
		return nil, errors.New("direction isn't valid")
	}

	var records Tasks
	err := h.DB.Select("*").
		From("task").
		Where("site_id = $1", siteID).
		OrderBy(orderByFieldName + " " + direction).
		Offset(uint64((pageNum - 1) * itemsPerPage)).
		Limit(uint64(itemsPerPage)).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	count := 0
	h.DB.SQL(`select count(task_id) from task where site_id = $1`, siteID).QueryStruct(&count)
	return NewPagedData(records, orderByFieldName, direction, itemsPerPage, pageNum, count), nil
}

func (h *taskHelper) Save(siteID int, record *Task) error {
	return h.save(siteID, record)
}

func (h *taskHelper) SaveMany(siteID int, records Tasks) error {
	for _, record := range records {
		err := h.save(siteID, record)
		if err != nil {
			return err
		}
	}

	return nil
}

func (h *taskHelper) save(siteID int, record *Task) error {
	err := h.beforeSave(record)
	if err != nil {
		return err
	}

	if record.SiteID != siteID {
		return errors.New("*Task update failed. SiteID Mismatch")
	}
	cols := []string{"description", "status", "date_created", "date_modified", "ulid", "site_id", "board_id", "reminder_date"}
	vals := []interface{}{record.Description, record.Status, record.DateCreated, record.DateModified, record.ULID, record.SiteID, record.BoardID, record.ReminderDate}
	if record.TaskID > 0 {
		// UPDATE
		b := h.DB.Update("task")
		for i := range cols {
			b.Set(cols[i], vals[i])
		}
		b.Where("task_id = $1", record.TaskID)
		b.Returning("task_id")
		err = b.QueryStruct(record)
	} else {
		// INSERT
		err = h.DB.
			InsertInto("task").
			Columns(cols...).
			Values(vals...).
			Returning("task_id").
			QueryStruct(record)
	}
	if err != nil {
		return err
	}
	err = h.afterSave(record)
	return err
}

func (h *taskHelper) Delete(siteID int, recordID int) (bool, error) {
	result, err := h.DB.
		DeleteFrom("task").
		Where("site_id=$1 and task_id=$2", siteID, recordID).
		Exec()

	if err != nil {
		return false, err
	}

	return (result.RowsAffected > 0), nil
}

func (h *taskHelper) validate(record *Task) (err error) {
	return nil
	//	validationErrors := h.validator.Struct(record)
	//	if validationErrors != nil {
	//		errMessage := ""
	//		for _, err := range err.(validator.ValidationErrors) {
	//			errMessage += err.Kind().String() + " validation Error on field "+err.Field()
	//		}
	//		if errMessage != "" {
	//			err = errors.New(errMessage)
	//		}
	//	}
	//	return err
}

func (task *Task) SaveActionables(siteID int) error {
	return ActionableHelper().SaveMany(siteID, task.Actionables)
}

func (task *Task) LoadActionables(siteID int) error {
	return task.LoadActionablesWhere(siteID, "task_id = $1 $SITEID", task.TaskID)
}

func (task *Task) LoadActionablesWhere(siteID int, sql string, args ...interface{}) error {
	children, err := ActionableHelper().Where(siteID, sql, args...)
	if err != nil {
		return err
	}
	task.Actionables = children
	return nil
}
