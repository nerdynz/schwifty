package models

import (
	"encoding/json"
	"errors"
	"net/http"
	"sort"
	"strings"
	"time"

	runner "github.com/nerdynz/dat/sqlx-runner"
	"github.com/nerdynz/security"
)

var clientHelperGlobal *clientHelper

// Client Record
type Client struct {
	ClientID     int       `db:"client_id" json:"ClientID"`
	ClientName   string    `db:"client_name" json:"ClientName"`
	Rate         int       `db:"rate" json:"Rate"`
	Address      string    `db:"address" json:"Address"`
	ContactName  string    `db:"contact_name" json:"ContactName"`
	DateCreated  time.Time `db:"date_created" json:"DateCreated"`
	DateModified time.Time `db:"date_modified" json:"DateModified"`
	SiteID       int       `db:"site_id" json:"SiteID"`
	ULID         string    `db:"ulid" json:"ULID"`

	Boards Boards `json:"Boards"`
	// BoardTaskCounts        BoardTaskCounts        `json:"BoardTaskCounts"`
	Contacts Contacts `json:"Contacts"`
	Invoices Invoices `json:"Invoices"`
	// Projects               Projects               `json:"Projects"`
	// ProjectInvoices        ProjectInvoices        `json:"ProjectInvoices"`
	TimeEntries TimeEntries `json:"TimeEntries"`
	// TitleTimeAutocompletes TitleTimeAutocompletes `json:"TitleTimeAutocompletes"`
	Jobs Jobs `json:"Jobs"`
}

type Clients []*Client

func (h *clientHelper) beforeSave(record *Client) (err error) {
	if record.DateCreated.IsZero() {
		record.DateCreated = time.Now()
	}
	record.DateModified = time.Now()
	if record.ULID == "" {
		record.ULID = security.ULID()
	}

	validationErr := h.validate(record)
	if validationErr != nil {
		return validationErr
	}
	return err
}

func (h *clientHelper) afterSave(record *Client) (err error) {
	return err
}

// GENERATED CODE - Leave the below code alone
type clientHelper struct {
	DB         *runner.DB
	Cache      Cache
	fieldNames []string
	orderBy    string
}

func ClientHelper() *clientHelper {
	if clientHelperGlobal == nil {
		clientHelperGlobal = newClientHelper(modelDB, modelCache)
	}
	return clientHelperGlobal
}

func newClientHelper(db *runner.DB, cache Cache) *clientHelper {
	helper := &clientHelper{}
	helper.DB = db
	helper.Cache = cache

	// Fields
	fieldnames := []string{"client_id", "client_name", "rate", "address", "contact_name", "date_created", "date_modified", "site_id", "ulid"}
	sort.Strings(fieldnames) // sort it makes searching it work correctly
	helper.fieldNames = fieldnames

	helper.orderBy = "date_created, date_modified"
	return helper
}

func (h *clientHelper) New(siteID int) *Client {
	record := &Client{}
	// check DateCreated
	record.DateCreated = time.Now()
	record.SiteID = siteID
	return record
}

func (h *clientHelper) FromRequest(siteID int, req *http.Request) (*Client, error) {
	record := h.New(siteID)
	contentType := req.Header.Get("Content-Type")
	if strings.Contains(contentType, "application/json") {
		// working with json
		decoder := json.NewDecoder(req.Body)
		err := decoder.Decode(record)
		if err != nil {
			return nil, err
		}
	} else {
		return nil, errors.New("Disabled - bring in h.structDecoder from gorilla")
		// // working with form values
		// err := req.ParseForm()
		// if err != nil {
		// 	return nil, err
		// }

		// err = h.structDecoder.Decode(record, req.PostForm)
		// if err != nil {
		// 	return nil, err
		// }
	}
	if record.SiteID != siteID {
		return nil, errors.New("*Client update failed. SiteID Mismatch")
	}
	record.SiteID = siteID
	return record, nil
}

func (h *clientHelper) Load(siteID int, id int) (*Client, error) {
	record, err := h.One(siteID, "client_id = $1", id)
	if err != nil {
		return nil, err
	}
	return record, nil
}

func (h *clientHelper) All(siteID int) (Clients, error) {
	var records Clients
	err := h.DB.Select("*").
		From("client").
		Where("site_id = $1", siteID).
		OrderBy(h.orderBy).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *clientHelper) Where(siteID int, sql string, args ...interface{}) (Clients, error) {
	var records Clients
	sql, args = appendSiteID(siteID, sql, args...)
	err := h.DB.Select("*").
		From("client").
		Where(sql, args...).
		OrderBy(h.orderBy).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *clientHelper) SQL(siteID int, sql string, args ...interface{}) (Clients, error) {
	if !strings.Contains(sql, "$SITEID") {
		return nil, errors.New("No $SITEID placeholder defined")
	}
	var records Clients
	sql, args = appendSiteID(siteID, sql, args...)
	err := h.DB.SQL(sql, args...).
		QueryStructs(&records)
	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *clientHelper) One(siteID int, sql string, args ...interface{}) (*Client, error) {
	var record Client
	sql, args = appendSiteID(siteID, sql, args...)

	err := h.DB.Select("*").
		From("client").
		Where(sql, args...).
		OrderBy(h.orderBy).
		Limit(1).
		QueryStruct(&record)

	if err != nil {
		return nil, err
	}

	return &record, nil
}

func (h *clientHelper) Paged(siteID int, pageNum int, itemsPerPage int) (*PagedData, error) {
	pd, err := h.PagedBy(siteID, pageNum, itemsPerPage, "date_created", "") // date_created should be the most consistant because it doesn't change
	if err != nil {
		return nil, err
	}
	return pd, nil
}

func (h *clientHelper) PagedBy(siteID int, pageNum int, itemsPerPage int, orderByFieldName string, direction string) (*PagedData, error) {
	if orderByFieldName == "" || orderByFieldName == "default" {
		// we only want the first field name
		orderByFieldName = strings.Split(h.orderBy, ",")[0]
		orderByFieldName = strings.Trim(orderByFieldName, " ")
	}
	i := sort.SearchStrings(h.fieldNames, orderByFieldName)
	// check the orderby exists within the fields as this could be an easy sql injection hole.
	if !(i < len(h.fieldNames) && h.fieldNames[i] == orderByFieldName) { // NOT
		return nil, errors.New("field name [" + orderByFieldName + "]  isn't a valid field name")
	}

	if !(direction == "asc" || direction == "desc" || direction == "") {
		return nil, errors.New("direction isn't valid")
	}

	var records Clients
	err := h.DB.Select("*").
		From("client").
		Where("site_id = $1", siteID).
		OrderBy(orderByFieldName + " " + direction).
		Offset(uint64((pageNum - 1) * itemsPerPage)).
		Limit(uint64(itemsPerPage)).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	count := 0
	h.DB.SQL(`select count(client_id) from client where site_id = $1`, siteID).QueryStruct(&count)
	return NewPagedData(records, orderByFieldName, direction, itemsPerPage, pageNum, count), nil
}

func (h *clientHelper) Save(siteID int, record *Client) error {
	return h.save(siteID, record)
}

func (h *clientHelper) SaveMany(siteID int, records Clients) error {
	for _, record := range records {
		err := h.save(siteID, record)
		if err != nil {
			return err
		}
	}

	return nil
}

func (h *clientHelper) save(siteID int, record *Client) error {
	err := h.beforeSave(record)
	if err != nil {
		return err
	}

	if record.SiteID != siteID {
		return errors.New("*Client update failed. SiteID Mismatch")
	}
	cols := []string{"client_name", "rate", "address", "contact_name", "date_created", "date_modified", "site_id", "ulid"}
	vals := []interface{}{record.ClientName, record.Rate, record.Address, record.ContactName, record.DateCreated, record.DateModified, record.SiteID, record.ULID}
	if record.ClientID > 0 {
		// UPDATE
		b := h.DB.Update("client")
		for i := range cols {
			b.Set(cols[i], vals[i])
		}
		b.Where("client_id = $1", record.ClientID)
		b.Returning("client_id")
		err = b.QueryStruct(record)
	} else {
		// INSERT
		err = h.DB.
			InsertInto("client").
			Columns(cols...).
			Values(vals...).
			Returning("client_id").
			QueryStruct(record)
	}
	if err != nil {
		return err
	}
	err = h.afterSave(record)
	return err
}

func (h *clientHelper) Delete(siteID int, recordID int) (bool, error) {
	result, err := h.DB.
		DeleteFrom("client").
		Where("site_id=$1 and client_id=$2", siteID, recordID).
		Exec()

	if err != nil {
		return false, err
	}

	return (result.RowsAffected > 0), nil
}

func (h *clientHelper) validate(record *Client) (err error) {
	return nil
	//	validationErrors := h.validator.Struct(record)
	//	if validationErrors != nil {
	//		errMessage := ""
	//		for _, err := range err.(validator.ValidationErrors) {
	//			errMessage += err.Kind().String() + " validation Error on field "+err.Field()
	//		}
	//		if errMessage != "" {
	//			err = errors.New(errMessage)
	//		}
	//	}
	//	return err
}

func (client *Client) SaveBoards(siteID int) error {
	return BoardHelper().SaveMany(siteID, client.Boards)
}

func (client *Client) LoadBoards(siteID int) error {
	return client.LoadBoardsWhere(siteID, "client_id = $1 $SITEID", client.ClientID)
}

func (client *Client) LoadBoardsWhere(siteID int, sql string, args ...interface{}) error {
	children, err := BoardHelper().Where(siteID, sql, args...)
	if err != nil {
		return err
	}
	client.Boards = children
	return nil
}

func (client *Client) SaveContacts(siteID int) error {
	return ContactHelper().SaveMany(siteID, client.Contacts)
}

func (client *Client) LoadContacts(siteID int) error {
	return client.LoadContactsWhere(siteID, "client_id = $1 $SITEID", client.ClientID)
}

func (client *Client) LoadContactsWhere(siteID int, sql string, args ...interface{}) error {
	children, err := ContactHelper().Where(siteID, sql, args...)
	if err != nil {
		return err
	}
	client.Contacts = children
	return nil
}

func (client *Client) SaveInvoices(siteID int) error {
	return InvoiceHelper().SaveMany(siteID, client.Invoices)
}

func (client *Client) LoadInvoices(siteID int) error {
	return client.LoadInvoicesWhere(siteID, "client_id = $1 $SITEID", client.ClientID)
}

func (client *Client) LoadInvoicesWhere(siteID int, sql string, args ...interface{}) error {
	children, err := InvoiceHelper().Where(siteID, sql, args...)
	if err != nil {
		return err
	}
	client.Invoices = children
	return nil
}

func (client *Client) SaveTimeEntries(siteID int) error {
	return TimeEntryHelper().SaveMany(siteID, client.TimeEntries)
}

func (client *Client) LoadTimeEntries(siteID int) error {
	return client.LoadTimeEntriesWhere(siteID, "client_id = $1 $SITEID", client.ClientID)
}

func (client *Client) LoadTimeEntriesWhere(siteID int, sql string, args ...interface{}) error {
	children, err := TimeEntryHelper().Where(siteID, sql, args...)
	if err != nil {
		return err
	}
	client.TimeEntries = children
	return nil
}

func (client *Client) SaveJobs(siteID int) error {
	return JobHelper().SaveMany(siteID, client.Jobs)
}

func (client *Client) LoadJobs(siteID int) error {
	return client.LoadJobsWhere(siteID, "client_id = $1 $SITEID", client.ClientID)
}

func (client *Client) LoadJobsWhere(siteID int, sql string, args ...interface{}) error {
	children, err := JobHelper().Where(siteID, sql, args...)
	if err != nil {
		return err
	}
	client.Jobs = children
	return nil
}
