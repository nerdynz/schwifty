package models

import (
	"encoding/json"
	"errors"
	"net/http"
	"sort"
	"strings"
	"time"

	runner "github.com/nerdynz/dat/sqlx-runner"
	"github.com/nerdynz/security"
)

var siteHelperGlobal *siteHelper

// Site Record
type Site struct {
	SiteID       int       `db:"site_id" json:"SiteID"`
	SiteName     string    `db:"site_name" json:"SiteName"`
	DateCreated  time.Time `db:"date_created" json:"DateCreated"`
	DateModified time.Time `db:"date_modified" json:"DateModified"`
	ULID         string    `db:"ulid" json:"ULID"`

	Boards      Boards      `json:"Boards"`
	Clients     Clients     `json:"Clients"`
	People      People      `json:"People"`
	Contacts    Contacts    `json:"Contacts"`
	Actionables Actionables `json:"Actionables"`
	Tasks       Tasks       `json:"Tasks"`
	// EFiles      EFiles      `json:"EFiles"`
	TimeEntries TimeEntries `json:"TimeEntries"`
	Jobs        Jobs        `json:"Jobs"`
	Milestones  Milestones  `json:"Milestones"`
	Invoices    Invoices    `json:"Invoices"`
	Settings    Settings    `json:"Settings"`
}

type Sites []*Site

func (h *siteHelper) beforeSave(record *Site) (err error) {
	if record.DateCreated.IsZero() {
		record.DateCreated = time.Now()
	}
	record.DateModified = time.Now()
	if record.ULID == "" {
		record.ULID = security.ULID()
	}

	validationErr := h.validate(record)
	if validationErr != nil {
		return validationErr
	}
	return err
}

func (h *siteHelper) afterSave(record *Site) (err error) {
	return err
}

// GENERATED CODE - Leave the below code alone
type siteHelper struct {
	DB         *runner.DB
	Cache      Cache
	fieldNames []string
	orderBy    string
}

func SiteHelper() *siteHelper {
	if siteHelperGlobal == nil {
		siteHelperGlobal = newSiteHelper(modelDB, modelCache)
	}
	return siteHelperGlobal
}

func newSiteHelper(db *runner.DB, cache Cache) *siteHelper {
	helper := &siteHelper{}
	helper.DB = db
	helper.Cache = cache

	// Fields
	fieldnames := []string{"site_id", "site_name", "date_created", "date_modified", "ulid"}
	sort.Strings(fieldnames) // sort it makes searching it work correctly
	helper.fieldNames = fieldnames

	helper.orderBy = "date_created, date_modified"
	return helper
}

func (h *siteHelper) New(siteID int) *Site {
	record := &Site{}
	// check DateCreated
	record.DateCreated = time.Now()
	record.SiteID = siteID
	return record
}

func (h *siteHelper) FromRequest(siteID int, req *http.Request) (*Site, error) {
	record := h.New(siteID)
	contentType := req.Header.Get("Content-Type")
	if strings.Contains(contentType, "application/json") {
		// working with json
		decoder := json.NewDecoder(req.Body)
		err := decoder.Decode(record)
		if err != nil {
			return nil, err
		}
	} else {
		return nil, errors.New("Disabled - bring in h.structDecoder from gorilla")
		// // working with form values
		// err := req.ParseForm()
		// if err != nil {
		// 	return nil, err
		// }

		// err = h.structDecoder.Decode(record, req.PostForm)
		// if err != nil {
		// 	return nil, err
		// }
	}
	if record.SiteID != siteID {
		return nil, errors.New("*Site update failed. SiteID Mismatch")
	}
	record.SiteID = siteID
	return record, nil
}

func (h *siteHelper) Load(siteID int, id int) (*Site, error) {
	record, err := h.One(siteID, "site_id = $1", id)
	if err != nil {
		return nil, err
	}
	return record, nil
}

func (h *siteHelper) All(siteID int) (Sites, error) {
	var records Sites
	err := h.DB.Select("*").
		From("site").
		Where("site_id = $1", siteID).
		OrderBy(h.orderBy).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *siteHelper) Where(siteID int, sql string, args ...interface{}) (Sites, error) {
	var records Sites
	sql, args = appendSiteID(siteID, sql, args...)
	err := h.DB.Select("*").
		From("site").
		Where(sql, args...).
		OrderBy(h.orderBy).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *siteHelper) SQL(siteID int, sql string, args ...interface{}) (Sites, error) {
	if !strings.Contains(sql, "$SITEID") {
		return nil, errors.New("No $SITEID placeholder defined")
	}
	var records Sites
	sql, args = appendSiteID(siteID, sql, args...)
	err := h.DB.SQL(sql, args...).
		QueryStructs(&records)
	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *siteHelper) One(siteID int, sql string, args ...interface{}) (*Site, error) {
	var record Site
	sql, args = appendSiteID(siteID, sql, args...)

	err := h.DB.Select("*").
		From("site").
		Where(sql, args...).
		OrderBy(h.orderBy).
		Limit(1).
		QueryStruct(&record)

	if err != nil {
		return nil, err
	}

	return &record, nil
}

func (h *siteHelper) Paged(siteID int, pageNum int, itemsPerPage int) (*PagedData, error) {
	pd, err := h.PagedBy(siteID, pageNum, itemsPerPage, "date_created", "") // date_created should be the most consistant because it doesn't change
	if err != nil {
		return nil, err
	}
	return pd, nil
}

func (h *siteHelper) PagedBy(siteID int, pageNum int, itemsPerPage int, orderByFieldName string, direction string) (*PagedData, error) {
	if orderByFieldName == "" || orderByFieldName == "default" {
		// we only want the first field name
		orderByFieldName = strings.Split(h.orderBy, ",")[0]
		orderByFieldName = strings.Trim(orderByFieldName, " ")
	}
	i := sort.SearchStrings(h.fieldNames, orderByFieldName)
	// check the orderby exists within the fields as this could be an easy sql injection hole.
	if !(i < len(h.fieldNames) && h.fieldNames[i] == orderByFieldName) { // NOT
		return nil, errors.New("field name [" + orderByFieldName + "]  isn't a valid field name")
	}

	if !(direction == "asc" || direction == "desc" || direction == "") {
		return nil, errors.New("direction isn't valid")
	}

	var records Sites
	err := h.DB.Select("*").
		From("site").
		Where("site_id = $1", siteID).
		OrderBy(orderByFieldName + " " + direction).
		Offset(uint64((pageNum - 1) * itemsPerPage)).
		Limit(uint64(itemsPerPage)).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	count := 0
	h.DB.SQL(`select count(site_id) from site where site_id = $1`, siteID).QueryStruct(&count)
	return NewPagedData(records, orderByFieldName, direction, itemsPerPage, pageNum, count), nil
}

func (h *siteHelper) Save(siteID int, record *Site) error {
	return h.save(siteID, record)
}

func (h *siteHelper) SaveMany(siteID int, records Sites) error {
	for _, record := range records {
		err := h.save(siteID, record)
		if err != nil {
			return err
		}
	}

	return nil
}

func (h *siteHelper) save(siteID int, record *Site) error {
	err := h.beforeSave(record)
	if err != nil {
		return err
	}

	if record.SiteID != siteID {
		return errors.New("*Site update failed. SiteID Mismatch")
	}
	cols := []string{"site_name", "date_created", "date_modified", "ulid"}
	vals := []interface{}{record.SiteName, record.DateCreated, record.DateModified, record.ULID}
	if record.SiteID > 0 {
		// UPDATE
		b := h.DB.Update("site")
		for i := range cols {
			b.Set(cols[i], vals[i])
		}
		b.Where("site_id = $1", record.SiteID)
		b.Returning("site_id")
		err = b.QueryStruct(record)
	} else {
		// INSERT
		err = h.DB.
			InsertInto("site").
			Columns(cols...).
			Values(vals...).
			Returning("site_id").
			QueryStruct(record)
	}
	if err != nil {
		return err
	}
	err = h.afterSave(record)
	return err
}

func (h *siteHelper) Delete(siteID int, recordID int) (bool, error) {
	result, err := h.DB.
		DeleteFrom("site").
		Where("site_id=$1 and site_id=$2", siteID, recordID).
		Exec()

	if err != nil {
		return false, err
	}

	return (result.RowsAffected > 0), nil
}

func (h *siteHelper) validate(record *Site) (err error) {
	return nil
	//	validationErrors := h.validator.Struct(record)
	//	if validationErrors != nil {
	//		errMessage := ""
	//		for _, err := range err.(validator.ValidationErrors) {
	//			errMessage += err.Kind().String() + " validation Error on field "+err.Field()
	//		}
	//		if errMessage != "" {
	//			err = errors.New(errMessage)
	//		}
	//	}
	//	return err
}

func (site *Site) SaveBoards(siteID int) error {
	return BoardHelper().SaveMany(siteID, site.Boards)
}

func (site *Site) LoadBoards(siteID int) error {
	return site.LoadBoardsWhere(siteID, "site_id = $1 $SITEID", site.SiteID)
}

func (site *Site) LoadBoardsWhere(siteID int, sql string, args ...interface{}) error {
	children, err := BoardHelper().Where(siteID, sql, args...)
	if err != nil {
		return err
	}
	site.Boards = children
	return nil
}

func (site *Site) SaveClients(siteID int) error {
	return ClientHelper().SaveMany(siteID, site.Clients)
}

func (site *Site) LoadClients(siteID int) error {
	return site.LoadClientsWhere(siteID, "site_id = $1 $SITEID", site.SiteID)
}

func (site *Site) LoadClientsWhere(siteID int, sql string, args ...interface{}) error {
	children, err := ClientHelper().Where(siteID, sql, args...)
	if err != nil {
		return err
	}
	site.Clients = children
	return nil
}

func (site *Site) SavePeople(siteID int) error {
	return PersonHelper().SaveMany(siteID, site.People)
}

func (site *Site) LoadPeople(siteID int) error {
	return site.LoadPeopleWhere(siteID, "site_id = $1 $SITEID", site.SiteID)
}

func (site *Site) LoadPeopleWhere(siteID int, sql string, args ...interface{}) error {
	children, err := PersonHelper().Where(siteID, sql, args...)
	if err != nil {
		return err
	}
	site.People = children
	return nil
}

func (site *Site) SaveContacts(siteID int) error {
	return ContactHelper().SaveMany(siteID, site.Contacts)
}

func (site *Site) LoadContacts(siteID int) error {
	return site.LoadContactsWhere(siteID, "site_id = $1 $SITEID", site.SiteID)
}

func (site *Site) LoadContactsWhere(siteID int, sql string, args ...interface{}) error {
	children, err := ContactHelper().Where(siteID, sql, args...)
	if err != nil {
		return err
	}
	site.Contacts = children
	return nil
}

func (site *Site) SaveActionables(siteID int) error {
	return ActionableHelper().SaveMany(siteID, site.Actionables)
}

func (site *Site) LoadActionables(siteID int) error {
	return site.LoadActionablesWhere(siteID, "site_id = $1 $SITEID", site.SiteID)
}

func (site *Site) LoadActionablesWhere(siteID int, sql string, args ...interface{}) error {
	children, err := ActionableHelper().Where(siteID, sql, args...)
	if err != nil {
		return err
	}
	site.Actionables = children
	return nil
}

func (site *Site) SaveTasks(siteID int) error {
	return TaskHelper().SaveMany(siteID, site.Tasks)
}

func (site *Site) LoadTasks(siteID int) error {
	return site.LoadTasksWhere(siteID, "site_id = $1 $SITEID", site.SiteID)
}

func (site *Site) LoadTasksWhere(siteID int, sql string, args ...interface{}) error {
	children, err := TaskHelper().Where(siteID, sql, args...)
	if err != nil {
		return err
	}
	site.Tasks = children
	return nil
}

// func (site *Site) SaveEFiles(siteID int) error {
// 	return EFileHelper().SaveMany(siteID, site.EFiles)
// }

// func (site *Site) LoadEFiles(siteID int) error {
// 	return site.LoadEFilesWhere(siteID, "site_id = $1 $SITEID", site.SiteID)
// }

// func (site *Site) LoadEFilesWhere(siteID int, sql string, args ...interface{}) error {
// 	children, err := EFileHelper().Where(siteID, sql, args...)
// 	if err != nil {
// 		return err
// 	}
// 	site.EFiles = children
// 	return nil
// }

func (site *Site) SaveTimeEntries(siteID int) error {
	return TimeEntryHelper().SaveMany(siteID, site.TimeEntries)
}

func (site *Site) LoadTimeEntries(siteID int) error {
	return site.LoadTimeEntriesWhere(siteID, "site_id = $1 $SITEID", site.SiteID)
}

func (site *Site) LoadTimeEntriesWhere(siteID int, sql string, args ...interface{}) error {
	children, err := TimeEntryHelper().Where(siteID, sql, args...)
	if err != nil {
		return err
	}
	site.TimeEntries = children
	return nil
}

func (site *Site) SaveJobs(siteID int) error {
	return JobHelper().SaveMany(siteID, site.Jobs)
}

func (site *Site) LoadJobs(siteID int) error {
	return site.LoadJobsWhere(siteID, "site_id = $1 $SITEID", site.SiteID)
}

func (site *Site) LoadJobsWhere(siteID int, sql string, args ...interface{}) error {
	children, err := JobHelper().Where(siteID, sql, args...)
	if err != nil {
		return err
	}
	site.Jobs = children
	return nil
}

func (site *Site) SaveMilestones(siteID int) error {
	return MilestoneHelper().SaveMany(siteID, site.Milestones)
}

func (site *Site) LoadMilestones(siteID int) error {
	return site.LoadMilestonesWhere(siteID, "site_id = $1 $SITEID", site.SiteID)
}

func (site *Site) LoadMilestonesWhere(siteID int, sql string, args ...interface{}) error {
	children, err := MilestoneHelper().Where(siteID, sql, args...)
	if err != nil {
		return err
	}
	site.Milestones = children
	return nil
}

func (site *Site) SaveInvoices(siteID int) error {
	return InvoiceHelper().SaveMany(siteID, site.Invoices)
}

func (site *Site) LoadInvoices(siteID int) error {
	return site.LoadInvoicesWhere(siteID, "site_id = $1 $SITEID", site.SiteID)
}

func (site *Site) LoadInvoicesWhere(siteID int, sql string, args ...interface{}) error {
	children, err := InvoiceHelper().Where(siteID, sql, args...)
	if err != nil {
		return err
	}
	site.Invoices = children
	return nil
}

func (site *Site) SaveSettings(siteID int) error {
	return SettingHelper().SaveMany(siteID, site.Settings)
}

func (site *Site) LoadSettings(siteID int) error {
	return site.LoadSettingsWhere(siteID, "site_id = $1 $SITEID", site.SiteID)
}

func (site *Site) LoadSettingsWhere(siteID int, sql string, args ...interface{}) error {
	children, err := SettingHelper().Where(siteID, sql, args...)
	if err != nil {
		return err
	}
	site.Settings = children
	return nil
}
