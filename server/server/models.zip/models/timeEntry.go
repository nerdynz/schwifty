package models

import (
	"encoding/json"
	"errors"
	"net/http"
	"sort"
	"strings"
	"time"

	runner "github.com/nerdynz/dat/sqlx-runner"
	"github.com/nerdynz/security"
)

var timeEntryHelperGlobal *timeEntryHelper

// TimeEntry Record
type TimeEntry struct {
	TimeEntryID  int       `db:"time_entry_id" json:"TimeEntryID"`
	StartTime    time.Time `db:"start_time" json:"StartTime"`
	EndTime      time.Time `db:"end_time" json:"EndTime"`
	Record       string    `db:"record" json:"Record"`
	Task         string    `db:"task" json:"Task"`
	ClientID     int       `db:"client_id" json:"ClientID"`
	Description  string    `db:"description" json:"Description"`
	InvoiceID    int       `db:"invoice_id" json:"InvoiceID"`
	DateCreated  time.Time `db:"date_created" json:"DateCreated"`
	DateModified time.Time `db:"date_modified" json:"DateModified"`
	ULID         string    `db:"ulid" json:"ULID"`
	SiteID       int       `db:"site_id" json:"SiteID"`
}

type TimeEntries []*TimeEntry

func (h *timeEntryHelper) beforeSave(record *TimeEntry) (err error) {
	if record.DateCreated.IsZero() {
		record.DateCreated = time.Now()
	}
	record.DateModified = time.Now()
	if record.ULID == "" {
		record.ULID = security.ULID()
	}

	validationErr := h.validate(record)
	if validationErr != nil {
		return validationErr
	}
	return err
}

func (h *timeEntryHelper) afterSave(record *TimeEntry) (err error) {
	return err
}

// GENERATED CODE - Leave the below code alone
type timeEntryHelper struct {
	DB         *runner.DB
	Cache      Cache
	fieldNames []string
	orderBy    string
}

func TimeEntryHelper() *timeEntryHelper {
	if timeEntryHelperGlobal == nil {
		timeEntryHelperGlobal = newTimeEntryHelper(modelDB, modelCache)
	}
	return timeEntryHelperGlobal
}

func newTimeEntryHelper(db *runner.DB, cache Cache) *timeEntryHelper {
	helper := &timeEntryHelper{}
	helper.DB = db
	helper.Cache = cache

	// Fields
	fieldnames := []string{"time_entry_id", "start_time", "end_time", "record", "task", "client_id", "description", "invoice_id", "date_created", "date_modified", "ulid", "site_id"}
	sort.Strings(fieldnames) // sort it makes searching it work correctly
	helper.fieldNames = fieldnames

	helper.orderBy = "date_created, date_modified"
	return helper
}

func (h *timeEntryHelper) New(siteID int) *TimeEntry {
	record := &TimeEntry{}
	// check DateCreated
	record.DateCreated = time.Now()
	record.SiteID = siteID
	return record
}

func (h *timeEntryHelper) FromRequest(siteID int, req *http.Request) (*TimeEntry, error) {
	record := h.New(siteID)
	contentType := req.Header.Get("Content-Type")
	if strings.Contains(contentType, "application/json") {
		// working with json
		decoder := json.NewDecoder(req.Body)
		err := decoder.Decode(record)
		if err != nil {
			return nil, err
		}
	} else {
		return nil, errors.New("Disabled - bring in h.structDecoder from gorilla")
		// // working with form values
		// err := req.ParseForm()
		// if err != nil {
		// 	return nil, err
		// }

		// err = h.structDecoder.Decode(record, req.PostForm)
		// if err != nil {
		// 	return nil, err
		// }
	}
	if record.SiteID != siteID {
		return nil, errors.New("*TimeEntry update failed. SiteID Mismatch")
	}
	record.SiteID = siteID
	return record, nil
}

func (h *timeEntryHelper) Load(siteID int, id int) (*TimeEntry, error) {
	record, err := h.One(siteID, "time_entry_id = $1", id)
	if err != nil {
		return nil, err
	}
	return record, nil
}

func (h *timeEntryHelper) All(siteID int) (TimeEntries, error) {
	var records TimeEntries
	err := h.DB.Select("*").
		From("time_entry").
		Where("site_id = $1", siteID).
		OrderBy(h.orderBy).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *timeEntryHelper) Where(siteID int, sql string, args ...interface{}) (TimeEntries, error) {
	var records TimeEntries
	sql, args = appendSiteID(siteID, sql, args...)
	err := h.DB.Select("*").
		From("time_entry").
		Where(sql, args...).
		OrderBy(h.orderBy).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *timeEntryHelper) SQL(siteID int, sql string, args ...interface{}) (TimeEntries, error) {
	if !strings.Contains(sql, "$SITEID") {
		return nil, errors.New("No $SITEID placeholder defined")
	}
	var records TimeEntries
	sql, args = appendSiteID(siteID, sql, args...)
	err := h.DB.SQL(sql, args...).
		QueryStructs(&records)
	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *timeEntryHelper) One(siteID int, sql string, args ...interface{}) (*TimeEntry, error) {
	var record TimeEntry
	sql, args = appendSiteID(siteID, sql, args...)

	err := h.DB.Select("*").
		From("time_entry").
		Where(sql, args...).
		OrderBy(h.orderBy).
		Limit(1).
		QueryStruct(&record)

	if err != nil {
		return nil, err
	}

	return &record, nil
}

func (h *timeEntryHelper) Paged(siteID int, pageNum int, itemsPerPage int) (*PagedData, error) {
	pd, err := h.PagedBy(siteID, pageNum, itemsPerPage, "date_created", "") // date_created should be the most consistant because it doesn't change
	if err != nil {
		return nil, err
	}
	return pd, nil
}

func (h *timeEntryHelper) PagedBy(siteID int, pageNum int, itemsPerPage int, orderByFieldName string, direction string) (*PagedData, error) {
	if orderByFieldName == "" || orderByFieldName == "default" {
		// we only want the first field name
		orderByFieldName = strings.Split(h.orderBy, ",")[0]
		orderByFieldName = strings.Trim(orderByFieldName, " ")
	}
	i := sort.SearchStrings(h.fieldNames, orderByFieldName)
	// check the orderby exists within the fields as this could be an easy sql injection hole.
	if !(i < len(h.fieldNames) && h.fieldNames[i] == orderByFieldName) { // NOT
		return nil, errors.New("field name [" + orderByFieldName + "]  isn't a valid field name")
	}

	if !(direction == "asc" || direction == "desc" || direction == "") {
		return nil, errors.New("direction isn't valid")
	}

	var records TimeEntries
	err := h.DB.Select("*").
		From("time_entry").
		Where("site_id = $1", siteID).
		OrderBy(orderByFieldName + " " + direction).
		Offset(uint64((pageNum - 1) * itemsPerPage)).
		Limit(uint64(itemsPerPage)).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	count := 0
	h.DB.SQL(`select count(time_entry_id) from time_entry where site_id = $1`, siteID).QueryStruct(&count)
	return NewPagedData(records, orderByFieldName, direction, itemsPerPage, pageNum, count), nil
}

func (h *timeEntryHelper) Save(siteID int, record *TimeEntry) error {
	return h.save(siteID, record)
}

func (h *timeEntryHelper) SaveMany(siteID int, records TimeEntries) error {
	for _, record := range records {
		err := h.save(siteID, record)
		if err != nil {
			return err
		}
	}

	return nil
}

func (h *timeEntryHelper) save(siteID int, record *TimeEntry) error {
	err := h.beforeSave(record)
	if err != nil {
		return err
	}

	if record.SiteID != siteID {
		return errors.New("*TimeEntry update failed. SiteID Mismatch")
	}
	cols := []string{"start_time", "end_time", "record", "task", "client_id", "description", "invoice_id", "date_created", "date_modified", "ulid", "site_id"}
	vals := []interface{}{record.StartTime, record.EndTime, record.Record, record.Task, record.ClientID, record.Description, record.InvoiceID, record.DateCreated, record.DateModified, record.ULID, record.SiteID}
	if record.TimeEntryID > 0 {
		// UPDATE
		b := h.DB.Update("time_entry")
		for i := range cols {
			b.Set(cols[i], vals[i])
		}
		b.Where("time_entry_id = $1", record.TimeEntryID)
		b.Returning("time_entry_id")
		err = b.QueryStruct(record)
	} else {
		// INSERT
		err = h.DB.
			InsertInto("time_entry").
			Columns(cols...).
			Values(vals...).
			Returning("time_entry_id").
			QueryStruct(record)
	}
	if err != nil {
		return err
	}
	err = h.afterSave(record)
	return err
}

func (h *timeEntryHelper) Delete(siteID int, recordID int) (bool, error) {
	result, err := h.DB.
		DeleteFrom("time_entry").
		Where("site_id=$1 and time_entry_id=$2", siteID, recordID).
		Exec()

	if err != nil {
		return false, err
	}

	return (result.RowsAffected > 0), nil
}

func (h *timeEntryHelper) validate(record *TimeEntry) (err error) {
	return nil
	//	validationErrors := h.validator.Struct(record)
	//	if validationErrors != nil {
	//		errMessage := ""
	//		for _, err := range err.(validator.ValidationErrors) {
	//			errMessage += err.Kind().String() + " validation Error on field "+err.Field()
	//		}
	//		if errMessage != "" {
	//			err = errors.New(errMessage)
	//		}
	//	}
	//	return err
}
