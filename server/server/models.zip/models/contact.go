package models

import (
	"encoding/json"
	"errors"
	"net/http"
	"sort"
	"strings"
	"time"

	runner "github.com/nerdynz/dat/sqlx-runner"
	"github.com/nerdynz/security"
)

var contactHelperGlobal *contactHelper

// Contact Record
type Contact struct {
	ContactID    int       `db:"contact_id" json:"ContactID"`
	Name         string    `db:"name" json:"Name"`
	Email        string    `db:"email" json:"Email"`
	Phone        string    `db:"phone" json:"Phone"`
	ClientID     int       `db:"client_id" json:"ClientID"`
	DateCreated  time.Time `db:"date_created" json:"DateCreated"`
	DateModified time.Time `db:"date_modified" json:"DateModified"`
	ULID         string    `db:"ulid" json:"ULID"`
	SiteID       int       `db:"site_id" json:"SiteID"`
}

type Contacts []*Contact

func (h *contactHelper) beforeSave(record *Contact) (err error) {
	if record.DateCreated.IsZero() {
		record.DateCreated = time.Now()
	}
	record.DateModified = time.Now()
	if record.ULID == "" {
		record.ULID = security.ULID()
	}

	validationErr := h.validate(record)
	if validationErr != nil {
		return validationErr
	}
	return err
}

func (h *contactHelper) afterSave(record *Contact) (err error) {
	return err
}

// GENERATED CODE - Leave the below code alone
type contactHelper struct {
	DB         *runner.DB
	Cache      Cache
	fieldNames []string
	orderBy    string
}

func ContactHelper() *contactHelper {
	if contactHelperGlobal == nil {
		contactHelperGlobal = newContactHelper(modelDB, modelCache)
	}
	return contactHelperGlobal
}

func newContactHelper(db *runner.DB, cache Cache) *contactHelper {
	helper := &contactHelper{}
	helper.DB = db
	helper.Cache = cache

	// Fields
	fieldnames := []string{"contact_id", "name", "email", "phone", "client_id", "date_created", "date_modified", "ulid", "site_id"}
	sort.Strings(fieldnames) // sort it makes searching it work correctly
	helper.fieldNames = fieldnames

	helper.orderBy = "date_created, date_modified"
	return helper
}

func (h *contactHelper) New(siteID int) *Contact {
	record := &Contact{}
	// check DateCreated
	record.DateCreated = time.Now()
	record.SiteID = siteID
	return record
}

func (h *contactHelper) FromRequest(siteID int, req *http.Request) (*Contact, error) {
	record := h.New(siteID)
	contentType := req.Header.Get("Content-Type")
	if strings.Contains(contentType, "application/json") {
		// working with json
		decoder := json.NewDecoder(req.Body)
		err := decoder.Decode(record)
		if err != nil {
			return nil, err
		}
	} else {
		return nil, errors.New("Disabled - bring in h.structDecoder from gorilla")
		// // working with form values
		// err := req.ParseForm()
		// if err != nil {
		// 	return nil, err
		// }

		// err = h.structDecoder.Decode(record, req.PostForm)
		// if err != nil {
		// 	return nil, err
		// }
	}
	if record.SiteID != siteID {
		return nil, errors.New("*Contact update failed. SiteID Mismatch")
	}
	record.SiteID = siteID
	return record, nil
}

func (h *contactHelper) Load(siteID int, id int) (*Contact, error) {
	record, err := h.One(siteID, "contact_id = $1", id)
	if err != nil {
		return nil, err
	}
	return record, nil
}

func (h *contactHelper) All(siteID int) (Contacts, error) {
	var records Contacts
	err := h.DB.Select("*").
		From("contact").
		Where("site_id = $1", siteID).
		OrderBy(h.orderBy).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *contactHelper) Where(siteID int, sql string, args ...interface{}) (Contacts, error) {
	var records Contacts
	sql, args = appendSiteID(siteID, sql, args...)
	err := h.DB.Select("*").
		From("contact").
		Where(sql, args...).
		OrderBy(h.orderBy).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *contactHelper) SQL(siteID int, sql string, args ...interface{}) (Contacts, error) {
	if !strings.Contains(sql, "$SITEID") {
		return nil, errors.New("No $SITEID placeholder defined")
	}
	var records Contacts
	sql, args = appendSiteID(siteID, sql, args...)
	err := h.DB.SQL(sql, args...).
		QueryStructs(&records)
	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *contactHelper) One(siteID int, sql string, args ...interface{}) (*Contact, error) {
	var record Contact
	sql, args = appendSiteID(siteID, sql, args...)

	err := h.DB.Select("*").
		From("contact").
		Where(sql, args...).
		OrderBy(h.orderBy).
		Limit(1).
		QueryStruct(&record)

	if err != nil {
		return nil, err
	}

	return &record, nil
}

func (h *contactHelper) Paged(siteID int, pageNum int, itemsPerPage int) (*PagedData, error) {
	pd, err := h.PagedBy(siteID, pageNum, itemsPerPage, "date_created", "") // date_created should be the most consistant because it doesn't change
	if err != nil {
		return nil, err
	}
	return pd, nil
}

func (h *contactHelper) PagedBy(siteID int, pageNum int, itemsPerPage int, orderByFieldName string, direction string) (*PagedData, error) {
	if orderByFieldName == "" || orderByFieldName == "default" {
		// we only want the first field name
		orderByFieldName = strings.Split(h.orderBy, ",")[0]
		orderByFieldName = strings.Trim(orderByFieldName, " ")
	}
	i := sort.SearchStrings(h.fieldNames, orderByFieldName)
	// check the orderby exists within the fields as this could be an easy sql injection hole.
	if !(i < len(h.fieldNames) && h.fieldNames[i] == orderByFieldName) { // NOT
		return nil, errors.New("field name [" + orderByFieldName + "]  isn't a valid field name")
	}

	if !(direction == "asc" || direction == "desc" || direction == "") {
		return nil, errors.New("direction isn't valid")
	}

	var records Contacts
	err := h.DB.Select("*").
		From("contact").
		Where("site_id = $1", siteID).
		OrderBy(orderByFieldName + " " + direction).
		Offset(uint64((pageNum - 1) * itemsPerPage)).
		Limit(uint64(itemsPerPage)).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	count := 0
	h.DB.SQL(`select count(contact_id) from contact where site_id = $1`, siteID).QueryStruct(&count)
	return NewPagedData(records, orderByFieldName, direction, itemsPerPage, pageNum, count), nil
}

func (h *contactHelper) Save(siteID int, record *Contact) error {
	return h.save(siteID, record)
}

func (h *contactHelper) SaveMany(siteID int, records Contacts) error {
	for _, record := range records {
		err := h.save(siteID, record)
		if err != nil {
			return err
		}
	}

	return nil
}

func (h *contactHelper) save(siteID int, record *Contact) error {
	err := h.beforeSave(record)
	if err != nil {
		return err
	}

	if record.SiteID != siteID {
		return errors.New("*Contact update failed. SiteID Mismatch")
	}
	cols := []string{"name", "email", "phone", "client_id", "date_created", "date_modified", "ulid", "site_id"}
	vals := []interface{}{record.Name, record.Email, record.Phone, record.ClientID, record.DateCreated, record.DateModified, record.ULID, record.SiteID}
	if record.ContactID > 0 {
		// UPDATE
		b := h.DB.Update("contact")
		for i := range cols {
			b.Set(cols[i], vals[i])
		}
		b.Where("contact_id = $1", record.ContactID)
		b.Returning("contact_id")
		err = b.QueryStruct(record)
	} else {
		// INSERT
		err = h.DB.
			InsertInto("contact").
			Columns(cols...).
			Values(vals...).
			Returning("contact_id").
			QueryStruct(record)
	}
	if err != nil {
		return err
	}
	err = h.afterSave(record)
	return err
}

func (h *contactHelper) Delete(siteID int, recordID int) (bool, error) {
	result, err := h.DB.
		DeleteFrom("contact").
		Where("site_id=$1 and contact_id=$2", siteID, recordID).
		Exec()

	if err != nil {
		return false, err
	}

	return (result.RowsAffected > 0), nil
}

func (h *contactHelper) validate(record *Contact) (err error) {
	return nil
	//	validationErrors := h.validator.Struct(record)
	//	if validationErrors != nil {
	//		errMessage := ""
	//		for _, err := range err.(validator.ValidationErrors) {
	//			errMessage += err.Kind().String() + " validation Error on field "+err.Field()
	//		}
	//		if errMessage != "" {
	//			err = errors.New(errMessage)
	//		}
	//	}
	//	return err
}
