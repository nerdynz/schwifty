CREATE TABLE "time_entry" (
    "time_entry_id" serial,
    "start_time" timestamptz,"end_time" timestamptz,"record" varchar(26),"task" text,"client_id" integer,"description" text,"invoice_id" integer,
    "date_created" timestamptz,
    "date_modified" timestamptz,
    
    "ulid" varchar(26),
    
    "site_id" integer,
    PRIMARY KEY ("time_entry_id")
);
