CREATE TABLE "e_file" (
    "e_file_id" serial,
    "name" text,"size" numeric,"type" text,"last_modified" timestamptz,"path" text,"record_id" integer,"record_type" text,
    "date_created" timestamptz,
    "date_modified" timestamptz,
    
    "ulid" varchar(26),
    
    "site_id" integer,
    PRIMARY KEY ("e_file_id")
);
