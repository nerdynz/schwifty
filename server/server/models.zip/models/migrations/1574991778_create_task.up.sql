CREATE TABLE "task" (
    "task_id" serial,
    "description" text,"status" text,
    "date_created" timestamptz,
    "date_modified" timestamptz,
    
    "ulid" varchar(26),
    
    "site_id" integer,
    PRIMARY KEY ("task_id")
);
