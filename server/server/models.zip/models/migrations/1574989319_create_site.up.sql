CREATE TABLE "site" (
    "site_id" serial,
    "site_name" text,
    "date_created" timestamptz,
    "date_modified" timestamptz,
    "ulid" varchar(26),
    PRIMARY KEY ("site_id")
);
