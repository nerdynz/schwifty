ALTER TABLE "milestone" DROP COLUMN IF EXISTS "title";

