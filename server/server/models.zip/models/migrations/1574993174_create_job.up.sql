CREATE TABLE "job" (
    "job_id" serial,
    "name" text,"client_id" integer,"status" text,"due_date" timestamptz,"notes" text,"quote_notes" text,
    "date_created" timestamptz,
    "date_modified" timestamptz,
    
    "ulid" varchar(26),
    
    "site_id" integer,
    PRIMARY KEY ("job_id")
);
