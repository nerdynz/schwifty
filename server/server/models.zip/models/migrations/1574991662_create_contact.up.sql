CREATE TABLE "contact" (
    "contact_id" serial,
    "name" text,"email" text,"phone" text,"client_id" integer,
    "date_created" timestamptz,
    "date_modified" timestamptz,
    
    "ulid" varchar(26),
    
    "site_id" integer,
    PRIMARY KEY ("contact_id")
);
