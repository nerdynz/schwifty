
 
ALTER TABLE "task" ADD COLUMN "reminder_date" timestamptz; 





