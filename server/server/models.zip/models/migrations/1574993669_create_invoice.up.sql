CREATE TABLE "invoice" (
    "invoice_id" serial,
    "notes" text,"invoice_number" text,"discount" numeric,"status" text,
    "date_created" timestamptz,
    "date_modified" timestamptz,
    
    "ulid" varchar(26),
    
    "site_id" integer,
    PRIMARY KEY ("invoice_id")
);
