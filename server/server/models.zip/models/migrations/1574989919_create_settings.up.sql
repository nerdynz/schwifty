CREATE TABLE "settings" (
    "settings_id" serial,
    "logo_picture" text,"primary_color" text,"secondary_color" text,
    "date_created" timestamptz,
    "date_modified" timestamptz,
    
    "ulid" varchar(26),
    
    "site_id" integer,
    PRIMARY KEY ("settings_id")
);
