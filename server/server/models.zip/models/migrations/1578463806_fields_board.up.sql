ALTER TABLE "board" ADD COLUMN "color" text DEFAULT '#ffffff; 
UPDATE "board" SET "color" = 0 where "color" is null;


