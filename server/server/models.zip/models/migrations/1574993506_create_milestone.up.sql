CREATE TABLE "milestone" (
    "milestone_id" serial,
    "description" text,"depth" integer,"job_id" text,"sort_position" text,
    "date_created" timestamptz,
    "date_modified" timestamptz,
    
    "ulid" varchar(26),
    
    "site_id" integer,
    PRIMARY KEY ("milestone_id")
);
