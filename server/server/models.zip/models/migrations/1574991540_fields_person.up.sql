
 
ALTER TABLE "person" ADD COLUMN "role" text; 



UPDATE "person" SET "role" = '' where "role" is null;



