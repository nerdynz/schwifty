ALTER TABLE "task" DROP COLUMN IF EXISTS "reminder_date";

