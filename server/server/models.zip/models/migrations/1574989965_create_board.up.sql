CREATE TABLE "board" (
    "board_id" serial,
    "name" text,"client_id" text,"is_active" boolean,
    "date_created" timestamptz,
    "date_modified" timestamptz,
    
    "ulid" varchar(26),
    
    "site_id" integer,
    PRIMARY KEY ("board_id")
);
