
 
ALTER TABLE "task" ADD COLUMN "board_id" integer; 


UPDATE "task" SET "board_id" = 0 where "board_id" is null;




