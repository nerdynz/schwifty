CREATE TABLE "client" (
    "client_id" serial,
    "name" text,
    "address" text,
    "logo" text,
    "rate" numeric,
    "date_created" timestamptz,
    "date_modified" timestamptz,
    "ulid" varchar(26),
    "site_id" integer,
    PRIMARY KEY ("client_id")
);
