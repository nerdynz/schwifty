CREATE TABLE "actionable" (
    "actionable_id" serial,
    "task_id" integer,"comment" text,"is_pinned" boolean,
    "date_created" timestamptz,
    "date_modified" timestamptz,
    
    "ulid" varchar(26),
    
    "site_id" integer,
    PRIMARY KEY ("actionable_id")
);
