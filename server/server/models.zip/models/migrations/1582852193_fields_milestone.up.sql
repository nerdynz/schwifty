
 



ALTER TABLE "milestone" ADD COLUMN "title" text DEFAULT ''; 
--UPDATE "milestone" SET "title" =  '' where "title" is null;



