CREATE TABLE "person" (
    "person_id" serial,
    "first_name" text,"last_name" text,"email" text,"password" text,"username" text,"initials" text,
    "date_created" timestamptz,
    "date_modified" timestamptz,
    
    "ulid" varchar(26),
    "site_id" integer,
    PRIMARY KEY ("person_id")
);
