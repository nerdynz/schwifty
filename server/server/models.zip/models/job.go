package models

import (
	"encoding/json"
	"errors"
	"net/http"
	"sort"
	"strings"
	"time"

	runner "github.com/nerdynz/dat/sqlx-runner"
	"github.com/nerdynz/security"
)

var jobHelperGlobal *jobHelper

// Job Record
type Job struct {
	JobID        int        `db:"job_id" json:"JobID"`
	Name         string     `db:"name" json:"Name"`
	Status       string     `db:"status" json:"Status"`
	DueDate      time.Time  `db:"due_date" json:"DueDate"`
	Notes        string     `db:"notes" json:"Notes"`
	QuoteNotes   string     `db:"quote_notes" json:"QuoteNotes"`
	DateCreated  time.Time  `db:"date_created" json:"DateCreated"`
	DateModified time.Time  `db:"date_modified" json:"DateModified"`
	ULID         string     `db:"ulid" json:"ULID"`
	SiteID       int        `db:"site_id" json:"SiteID"`
	ClientID     int        `db:"client_id" json:"ClientID"`
	Milestones   Milestones `json:"Milestones"`
}

type Jobs []*Job

func (h *jobHelper) beforeSave(record *Job) (err error) {
	if record.DateCreated.IsZero() {
		record.DateCreated = time.Now()
	}
	record.DateModified = time.Now()
	if record.ULID == "" {
		record.ULID = security.ULID()
	}

	validationErr := h.validate(record)
	if validationErr != nil {
		return validationErr
	}
	return err
}

func (h *jobHelper) afterSave(record *Job) (err error) {
	return err
}

// GENERATED CODE - Leave the below code alone
type jobHelper struct {
	DB         *runner.DB
	Cache      Cache
	fieldNames []string
	orderBy    string
}

func JobHelper() *jobHelper {
	if jobHelperGlobal == nil {
		jobHelperGlobal = newJobHelper(modelDB, modelCache)
	}
	return jobHelperGlobal
}

func newJobHelper(db *runner.DB, cache Cache) *jobHelper {
	helper := &jobHelper{}
	helper.DB = db
	helper.Cache = cache

	// Fields
	fieldnames := []string{"job_id", "name", "client_id", "status", "due_date", "notes", "quote_notes", "date_created", "date_modified", "ulid", "site_id"}
	sort.Strings(fieldnames) // sort it makes searching it work correctly
	helper.fieldNames = fieldnames

	helper.orderBy = "date_created, date_modified"
	return helper
}

func (h *jobHelper) New(siteID int) *Job {
	record := &Job{}
	// check DateCreated
	record.DateCreated = time.Now()
	record.SiteID = siteID
	return record
}

func (h *jobHelper) FromRequest(siteID int, req *http.Request) (*Job, error) {
	record := h.New(siteID)
	contentType := req.Header.Get("Content-Type")
	if strings.Contains(contentType, "application/json") {
		// working with json
		decoder := json.NewDecoder(req.Body)
		err := decoder.Decode(record)
		if err != nil {
			return nil, err
		}
	} else {
		return nil, errors.New("Disabled - bring in h.structDecoder from gorilla")
		// // working with form values
		// err := req.ParseForm()
		// if err != nil {
		// 	return nil, err
		// }

		// err = h.structDecoder.Decode(record, req.PostForm)
		// if err != nil {
		// 	return nil, err
		// }
	}
	if record.SiteID != siteID {
		return nil, errors.New("*Job update failed. SiteID Mismatch")
	}
	record.SiteID = siteID
	return record, nil
}

func (h *jobHelper) Load(siteID int, id int) (*Job, error) {
	record, err := h.One(siteID, "job_id = $1", id)
	if err != nil {
		return nil, err
	}
	return record, nil
}

func (h *jobHelper) All(siteID int) (Jobs, error) {
	var records Jobs
	err := h.DB.Select("*").
		From("job").
		Where("site_id = $1", siteID).
		OrderBy(h.orderBy).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *jobHelper) Where(siteID int, sql string, args ...interface{}) (Jobs, error) {
	var records Jobs
	sql, args = appendSiteID(siteID, sql, args...)
	err := h.DB.Select("*").
		From("job").
		Where(sql, args...).
		OrderBy(h.orderBy).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *jobHelper) SQL(siteID int, sql string, args ...interface{}) (Jobs, error) {
	if !strings.Contains(sql, "$SITEID") {
		return nil, errors.New("No $SITEID placeholder defined")
	}
	var records Jobs
	sql, args = appendSiteID(siteID, sql, args...)
	err := h.DB.SQL(sql, args...).
		QueryStructs(&records)
	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *jobHelper) One(siteID int, sql string, args ...interface{}) (*Job, error) {
	var record Job
	sql, args = appendSiteID(siteID, sql, args...)

	err := h.DB.Select("*").
		From("job").
		Where(sql, args...).
		OrderBy(h.orderBy).
		Limit(1).
		QueryStruct(&record)

	if err != nil {
		return nil, err
	}

	return &record, nil
}

func (h *jobHelper) Paged(siteID int, pageNum int, itemsPerPage int) (*PagedData, error) {
	pd, err := h.PagedBy(siteID, pageNum, itemsPerPage, "date_created", "") // date_created should be the most consistant because it doesn't change
	if err != nil {
		return nil, err
	}
	return pd, nil
}

func (h *jobHelper) PagedBy(siteID int, pageNum int, itemsPerPage int, orderByFieldName string, direction string) (*PagedData, error) {
	if orderByFieldName == "" || orderByFieldName == "default" {
		// we only want the first field name
		orderByFieldName = strings.Split(h.orderBy, ",")[0]
		orderByFieldName = strings.Trim(orderByFieldName, " ")
	}
	i := sort.SearchStrings(h.fieldNames, orderByFieldName)
	// check the orderby exists within the fields as this could be an easy sql injection hole.
	if !(i < len(h.fieldNames) && h.fieldNames[i] == orderByFieldName) { // NOT
		return nil, errors.New("field name [" + orderByFieldName + "]  isn't a valid field name")
	}

	if !(direction == "asc" || direction == "desc" || direction == "") {
		return nil, errors.New("direction isn't valid")
	}

	var records Jobs
	err := h.DB.Select("*").
		From("job").
		Where("site_id = $1", siteID).
		OrderBy(orderByFieldName + " " + direction).
		Offset(uint64((pageNum - 1) * itemsPerPage)).
		Limit(uint64(itemsPerPage)).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	count := 0
	h.DB.SQL(`select count(job_id) from job where site_id = $1`, siteID).QueryStruct(&count)
	return NewPagedData(records, orderByFieldName, direction, itemsPerPage, pageNum, count), nil
}

func (h *jobHelper) Save(siteID int, record *Job) error {
	return h.save(siteID, record)
}

func (h *jobHelper) SaveMany(siteID int, records Jobs) error {
	for _, record := range records {
		err := h.save(siteID, record)
		if err != nil {
			return err
		}
	}

	return nil
}

func (h *jobHelper) save(siteID int, record *Job) error {
	err := h.beforeSave(record)
	if err != nil {
		return err
	}

	if record.SiteID != siteID {
		return errors.New("*Job update failed. SiteID Mismatch")
	}
	cols := []string{"name", "client_id", "status", "due_date", "notes", "quote_notes", "date_created", "date_modified", "ulid", "site_id"}
	vals := []interface{}{record.Name, record.ClientID, record.Status, record.DueDate, record.Notes, record.QuoteNotes, record.DateCreated, record.DateModified, record.ULID, record.SiteID}
	if record.JobID > 0 {
		// UPDATE
		b := h.DB.Update("job")
		for i := range cols {
			b.Set(cols[i], vals[i])
		}
		b.Where("job_id = $1", record.JobID)
		b.Returning("job_id")
		err = b.QueryStruct(record)
	} else {
		// INSERT
		err = h.DB.
			InsertInto("job").
			Columns(cols...).
			Values(vals...).
			Returning("job_id").
			QueryStruct(record)
	}
	if err != nil {
		return err
	}
	err = h.afterSave(record)
	return err
}

func (h *jobHelper) Delete(siteID int, recordID int) (bool, error) {
	result, err := h.DB.
		DeleteFrom("job").
		Where("site_id=$1 and job_id=$2", siteID, recordID).
		Exec()

	if err != nil {
		return false, err
	}

	return (result.RowsAffected > 0), nil
}

func (h *jobHelper) validate(record *Job) (err error) {
	return nil
	//	validationErrors := h.validator.Struct(record)
	//	if validationErrors != nil {
	//		errMessage := ""
	//		for _, err := range err.(validator.ValidationErrors) {
	//			errMessage += err.Kind().String() + " validation Error on field "+err.Field()
	//		}
	//		if errMessage != "" {
	//			err = errors.New(errMessage)
	//		}
	//	}
	//	return err
}

func (job *Job) SaveMilestones(siteID int) error {
	for _, mi := range job.Milestones {
		mi.JobID = job.JobID
	}
	return MilestoneHelper().SaveMany(siteID, job.Milestones)
}

func (job *Job) LoadMilestones(siteID int) error {
	return job.LoadMilestonesWhere(siteID, "job_id = $1 $SITEID", job.JobID)
}

func (job *Job) LoadMilestonesWhere(siteID int, sql string, args ...interface{}) error {
	children, err := MilestoneHelper().Where(siteID, sql, args...)
	if err != nil {
		return err
	}
	job.Milestones = children
	return nil
}
