package models

import (
	"encoding/json"
	"errors"
	"net/http"
	"sort"
	"strings"
	"time"

	runner "github.com/nerdynz/dat/sqlx-runner"
	"github.com/nerdynz/security"
)

var boardHelperGlobal *boardHelper

// Board Record
type Board struct {
	BoardID      int       `db:"board_id" json:"BoardID"`
	Name         string    `db:"name" json:"Name"`
	ClientID     string    `db:"client_id" json:"ClientID"`
	IsActive     bool      `db:"is_active" json:"IsActive"`
	DateCreated  time.Time `db:"date_created" json:"DateCreated"`
	DateModified time.Time `db:"date_modified" json:"DateModified"`
	ULID         string    `db:"ulid" json:"ULID"`
	SiteID       int       `db:"site_id" json:"SiteID"`
	Color        string    `db:"color" json:"Color"`

	Tasks Tasks `json:"Tasks"`
}

type Boards []*Board

func (h *boardHelper) beforeSave(record *Board) (err error) {
	if record.DateCreated.IsZero() {
		record.DateCreated = time.Now()
	}
	record.DateModified = time.Now()
	if record.ULID == "" {
		record.ULID = security.ULID()
	}

	validationErr := h.validate(record)
	if validationErr != nil {
		return validationErr
	}
	return err
}

func (h *boardHelper) afterSave(record *Board) (err error) {
	return err
}

// GENERATED CODE - Leave the below code alone
type boardHelper struct {
	DB         *runner.DB
	Cache      Cache
	fieldNames []string
	orderBy    string
}

func BoardHelper() *boardHelper {
	if boardHelperGlobal == nil {
		boardHelperGlobal = newBoardHelper(modelDB, modelCache)
	}
	return boardHelperGlobal
}

func newBoardHelper(db *runner.DB, cache Cache) *boardHelper {
	helper := &boardHelper{}
	helper.DB = db
	helper.Cache = cache

	// Fields
	fieldnames := []string{"board_id", "name", "client_id", "is_active", "date_created", "date_modified", "ulid", "site_id", "color"}
	sort.Strings(fieldnames) // sort it makes searching it work correctly
	helper.fieldNames = fieldnames

	helper.orderBy = "date_created, date_modified"
	return helper
}

func (h *boardHelper) New(siteID int) *Board {
	record := &Board{}
	// check DateCreated
	record.DateCreated = time.Now()
	record.SiteID = siteID
	record.Name = "New Board"
	return record
}

func (h *boardHelper) FromRequest(siteID int, req *http.Request) (*Board, error) {
	record := h.New(siteID)
	contentType := req.Header.Get("Content-Type")
	if strings.Contains(contentType, "application/json") {
		// working with json
		decoder := json.NewDecoder(req.Body)
		err := decoder.Decode(record)
		if err != nil {
			return nil, err
		}
	} else {
		return nil, errors.New("Disabled - bring in h.structDecoder from gorilla")
		// // working with form values
		// err := req.ParseForm()
		// if err != nil {
		// 	return nil, err
		// }

		// err = h.structDecoder.Decode(record, req.PostForm)
		// if err != nil {
		// 	return nil, err
		// }
	}
	if record.SiteID != siteID {
		return nil, errors.New("*Board update failed. SiteID Mismatch")
	}
	record.SiteID = siteID
	return record, nil
}

func (h *boardHelper) Load(siteID int, id int) (*Board, error) {
	record, err := h.One(siteID, "board_id = $1", id)
	if err != nil {
		return nil, err
	}
	return record, nil
}

func (h *boardHelper) All(siteID int) (Boards, error) {
	var records Boards
	err := h.DB.Select("*").
		From("board").
		Where("site_id = $1", siteID).
		OrderBy(h.orderBy).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *boardHelper) Where(siteID int, sql string, args ...interface{}) (Boards, error) {
	var records Boards
	sql, args = appendSiteID(siteID, sql, args...)
	err := h.DB.Select("*").
		From("board").
		Where(sql, args...).
		OrderBy(h.orderBy).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *boardHelper) SQL(siteID int, sql string, args ...interface{}) (Boards, error) {
	if !strings.Contains(sql, "$SITEID") {
		return nil, errors.New("No $SITEID placeholder defined")
	}
	var records Boards
	sql, args = appendSiteID(siteID, sql, args...)
	err := h.DB.SQL(sql, args...).
		QueryStructs(&records)
	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *boardHelper) One(siteID int, sql string, args ...interface{}) (*Board, error) {
	var record Board
	sql, args = appendSiteID(siteID, sql, args...)

	err := h.DB.Select("*").
		From("board").
		Where(sql, args...).
		OrderBy(h.orderBy).
		Limit(1).
		QueryStruct(&record)

	if err != nil {
		return nil, err
	}

	return &record, nil
}

func (h *boardHelper) Paged(siteID int, pageNum int, itemsPerPage int) (*PagedData, error) {
	pd, err := h.PagedBy(siteID, pageNum, itemsPerPage, "date_created", "") // date_created should be the most consistant because it doesn't change
	if err != nil {
		return nil, err
	}
	return pd, nil
}

func (h *boardHelper) PagedBy(siteID int, pageNum int, itemsPerPage int, orderByFieldName string, direction string) (*PagedData, error) {
	if orderByFieldName == "" || orderByFieldName == "default" {
		// we only want the first field name
		orderByFieldName = strings.Split(h.orderBy, ",")[0]
		orderByFieldName = strings.Trim(orderByFieldName, " ")
	}
	i := sort.SearchStrings(h.fieldNames, orderByFieldName)
	// check the orderby exists within the fields as this could be an easy sql injection hole.
	if !(i < len(h.fieldNames) && h.fieldNames[i] == orderByFieldName) { // NOT
		return nil, errors.New("field name [" + orderByFieldName + "]  isn't a valid field name")
	}

	if !(direction == "asc" || direction == "desc" || direction == "") {
		return nil, errors.New("direction isn't valid")
	}

	var records Boards
	err := h.DB.Select("*").
		From("board").
		Where("site_id = $1", siteID).
		OrderBy(orderByFieldName + " " + direction).
		Offset(uint64((pageNum - 1) * itemsPerPage)).
		Limit(uint64(itemsPerPage)).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	count := 0
	h.DB.SQL(`select count(board_id) from board where site_id = $1`, siteID).QueryStruct(&count)
	return NewPagedData(records, orderByFieldName, direction, itemsPerPage, pageNum, count), nil
}

func (h *boardHelper) Save(siteID int, record *Board) error {
	return h.save(siteID, record)
}

func (h *boardHelper) SaveMany(siteID int, records Boards) error {
	for _, record := range records {
		err := h.save(siteID, record)
		if err != nil {
			return err
		}
	}

	return nil
}

func (h *boardHelper) save(siteID int, record *Board) error {
	err := h.beforeSave(record)
	if err != nil {
		return err
	}

	if record.SiteID != siteID {
		return errors.New("*Board update failed. SiteID Mismatch")
	}
	cols := []string{"name", "client_id", "is_active", "date_created", "date_modified", "ulid", "site_id", "color"}
	vals := []interface{}{record.Name, record.ClientID, record.IsActive, record.DateCreated, record.DateModified, record.ULID, record.SiteID, record.Color}
	if record.BoardID > 0 {
		// UPDATE
		b := h.DB.Update("board")
		for i := range cols {
			b.Set(cols[i], vals[i])
		}
		b.Where("board_id = $1", record.BoardID)
		b.Returning("board_id")
		err = b.QueryStruct(record)
	} else {
		// INSERT
		err = h.DB.
			InsertInto("board").
			Columns(cols...).
			Values(vals...).
			Returning("board_id").
			QueryStruct(record)
	}
	if err != nil {
		return err
	}
	err = h.afterSave(record)
	return err
}

func (h *boardHelper) Delete(siteID int, recordID int) (bool, error) {
	result, err := h.DB.
		DeleteFrom("board").
		Where("site_id=$1 and board_id=$2", siteID, recordID).
		Exec()

	if err != nil {
		return false, err
	}

	return (result.RowsAffected > 0), nil
}

func (h *boardHelper) validate(record *Board) (err error) {
	return nil
	//	validationErrors := h.validator.Struct(record)
	//	if validationErrors != nil {
	//		errMessage := ""
	//		for _, err := range err.(validator.ValidationErrors) {
	//			errMessage += err.Kind().String() + " validation Error on field "+err.Field()
	//		}
	//		if errMessage != "" {
	//			err = errors.New(errMessage)
	//		}
	//	}
	//	return err
}

func (board *Board) SaveTasks(siteID int) error {
	return TaskHelper().SaveMany(siteID, board.Tasks)
}

func (board *Board) LoadTasks(siteID int) error {
	return board.LoadTasksWhere(siteID, "board_id = $1 $SITEID", board.BoardID)
}

func (board *Board) LoadTasksWhere(siteID int, sql string, args ...interface{}) error {
	children, err := TaskHelper().Where(siteID, sql, args...)
	if err != nil {
		return err
	}
	board.Tasks = children
	return nil
}
