package models

import (
	"encoding/json"
	"errors"
	"net/http"
	"sort"
	"strings"
	"time"

	runner "github.com/nerdynz/dat/sqlx-runner"
	"github.com/nerdynz/security"
)

var actionableHelperGlobal *actionableHelper

// Actionable Record
type Actionable struct {
	ActionableID int       `db:"actionable_id" json:"ActionableID"`
	TaskID       int       `db:"task_id" json:"TaskID"`
	Comment      string    `db:"comment" json:"Comment"`
	IsPinned     bool      `db:"is_pinned" json:"IsPinned"`
	DateCreated  time.Time `db:"date_created" json:"DateCreated"`
	DateModified time.Time `db:"date_modified" json:"DateModified"`
	ULID         string    `db:"ulid" json:"ULID"`
	SiteID       int       `db:"site_id" json:"SiteID"`
}

type Actionables []*Actionable

func (h *actionableHelper) beforeSave(record *Actionable) (err error) {
	if record.DateCreated.IsZero() {
		record.DateCreated = time.Now()
	}
	record.DateModified = time.Now()
	if record.ULID == "" {
		record.ULID = security.ULID()
	}

	validationErr := h.validate(record)
	if validationErr != nil {
		return validationErr
	}
	return err
}

func (h *actionableHelper) afterSave(record *Actionable) (err error) {
	return err
}

// GENERATED CODE - Leave the below code alone
type actionableHelper struct {
	DB         *runner.DB
	Cache      Cache
	fieldNames []string
	orderBy    string
}

func ActionableHelper() *actionableHelper {
	if actionableHelperGlobal == nil {
		actionableHelperGlobal = newActionableHelper(modelDB, modelCache)
	}
	return actionableHelperGlobal
}

func newActionableHelper(db *runner.DB, cache Cache) *actionableHelper {
	helper := &actionableHelper{}
	helper.DB = db
	helper.Cache = cache

	// Fields
	fieldnames := []string{"actionable_id", "task_id", "comment", "is_pinned", "date_created", "date_modified", "ulid", "site_id"}
	sort.Strings(fieldnames) // sort it makes searching it work correctly
	helper.fieldNames = fieldnames

	helper.orderBy = "date_created, date_modified"
	return helper
}

func (h *actionableHelper) New(siteID int) *Actionable {
	record := &Actionable{}
	// check DateCreated
	record.DateCreated = time.Now()
	record.SiteID = siteID
	return record
}

func (h *actionableHelper) FromRequest(siteID int, req *http.Request) (*Actionable, error) {
	record := h.New(siteID)
	contentType := req.Header.Get("Content-Type")
	if strings.Contains(contentType, "application/json") {
		// working with json
		decoder := json.NewDecoder(req.Body)
		err := decoder.Decode(record)
		if err != nil {
			return nil, err
		}
	} else {
		return nil, errors.New("Disabled - bring in h.structDecoder from gorilla")
		// // working with form values
		// err := req.ParseForm()
		// if err != nil {
		// 	return nil, err
		// }

		// err = h.structDecoder.Decode(record, req.PostForm)
		// if err != nil {
		// 	return nil, err
		// }
	}
	if record.SiteID != siteID {
		return nil, errors.New("*Actionable update failed. SiteID Mismatch")
	}
	record.SiteID = siteID
	return record, nil
}

func (h *actionableHelper) Load(siteID int, id int) (*Actionable, error) {
	record, err := h.One(siteID, "actionable_id = $1", id)
	if err != nil {
		return nil, err
	}
	return record, nil
}

func (h *actionableHelper) All(siteID int) (Actionables, error) {
	var records Actionables
	err := h.DB.Select("*").
		From("actionable").
		Where("site_id = $1", siteID).
		OrderBy(h.orderBy).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *actionableHelper) Where(siteID int, sql string, args ...interface{}) (Actionables, error) {
	var records Actionables
	sql, args = appendSiteID(siteID, sql, args...)
	err := h.DB.Select("*").
		From("actionable").
		Where(sql, args...).
		OrderBy(h.orderBy).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *actionableHelper) SQL(siteID int, sql string, args ...interface{}) (Actionables, error) {
	if !strings.Contains(sql, "$SITEID") {
		return nil, errors.New("No $SITEID placeholder defined")
	}
	var records Actionables
	sql, args = appendSiteID(siteID, sql, args...)
	err := h.DB.SQL(sql, args...).
		QueryStructs(&records)
	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *actionableHelper) One(siteID int, sql string, args ...interface{}) (*Actionable, error) {
	var record Actionable
	sql, args = appendSiteID(siteID, sql, args...)

	err := h.DB.Select("*").
		From("actionable").
		Where(sql, args...).
		OrderBy(h.orderBy).
		Limit(1).
		QueryStruct(&record)

	if err != nil {
		return nil, err
	}

	return &record, nil
}

func (h *actionableHelper) Paged(siteID int, pageNum int, itemsPerPage int) (*PagedData, error) {
	pd, err := h.PagedBy(siteID, pageNum, itemsPerPage, "date_created", "") // date_created should be the most consistant because it doesn't change
	if err != nil {
		return nil, err
	}
	return pd, nil
}

func (h *actionableHelper) PagedBy(siteID int, pageNum int, itemsPerPage int, orderByFieldName string, direction string) (*PagedData, error) {
	if orderByFieldName == "" || orderByFieldName == "default" {
		// we only want the first field name
		orderByFieldName = strings.Split(h.orderBy, ",")[0]
		orderByFieldName = strings.Trim(orderByFieldName, " ")
	}
	i := sort.SearchStrings(h.fieldNames, orderByFieldName)
	// check the orderby exists within the fields as this could be an easy sql injection hole.
	if !(i < len(h.fieldNames) && h.fieldNames[i] == orderByFieldName) { // NOT
		return nil, errors.New("field name [" + orderByFieldName + "]  isn't a valid field name")
	}

	if !(direction == "asc" || direction == "desc" || direction == "") {
		return nil, errors.New("direction isn't valid")
	}

	var records Actionables
	err := h.DB.Select("*").
		From("actionable").
		Where("site_id = $1", siteID).
		OrderBy(orderByFieldName + " " + direction).
		Offset(uint64((pageNum - 1) * itemsPerPage)).
		Limit(uint64(itemsPerPage)).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	count := 0
	h.DB.SQL(`select count(actionable_id) from actionable where site_id = $1`, siteID).QueryStruct(&count)
	return NewPagedData(records, orderByFieldName, direction, itemsPerPage, pageNum, count), nil
}

func (h *actionableHelper) Save(siteID int, record *Actionable) error {
	return h.save(siteID, record)
}

func (h *actionableHelper) SaveMany(siteID int, records Actionables) error {
	for _, record := range records {
		err := h.save(siteID, record)
		if err != nil {
			return err
		}
	}

	return nil
}

func (h *actionableHelper) save(siteID int, record *Actionable) error {
	err := h.beforeSave(record)
	if err != nil {
		return err
	}

	if record.SiteID != siteID {
		return errors.New("*Actionable update failed. SiteID Mismatch")
	}
	cols := []string{"task_id", "comment", "is_pinned", "date_created", "date_modified", "ulid", "site_id"}
	vals := []interface{}{record.TaskID, record.Comment, record.IsPinned, record.DateCreated, record.DateModified, record.ULID, record.SiteID}
	if record.ActionableID > 0 {
		// UPDATE
		b := h.DB.Update("actionable")
		for i := range cols {
			b.Set(cols[i], vals[i])
		}
		b.Where("actionable_id = $1", record.ActionableID)
		b.Returning("actionable_id")
		err = b.QueryStruct(record)
	} else {
		// INSERT
		err = h.DB.
			InsertInto("actionable").
			Columns(cols...).
			Values(vals...).
			Returning("actionable_id").
			QueryStruct(record)
	}
	if err != nil {
		return err
	}
	err = h.afterSave(record)
	return err
}

func (h *actionableHelper) Delete(siteID int, recordID int) (bool, error) {
	result, err := h.DB.
		DeleteFrom("actionable").
		Where("site_id=$1 and actionable_id=$2", siteID, recordID).
		Exec()

	if err != nil {
		return false, err
	}

	return (result.RowsAffected > 0), nil
}

func (h *actionableHelper) validate(record *Actionable) (err error) {
	return nil
	//	validationErrors := h.validator.Struct(record)
	//	if validationErrors != nil {
	//		errMessage := ""
	//		for _, err := range err.(validator.ValidationErrors) {
	//			errMessage += err.Kind().String() + " validation Error on field "+err.Field()
	//		}
	//		if errMessage != "" {
	//			err = errors.New(errMessage)
	//		}
	//	}
	//	return err
}
