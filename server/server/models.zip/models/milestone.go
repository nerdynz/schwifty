package models

import (
	"encoding/json"
	"errors"
	"net/http"
	"sort"
	"strings"
	"time"

	runner "github.com/nerdynz/dat/sqlx-runner"
	"github.com/nerdynz/security"
)

var milestoneHelperGlobal *milestoneHelper

// Milestone Record
type Milestone struct {
	MilestoneID  int       `db:"milestone_id" json:"MilestoneID"`
	Description  string    `db:"description" json:"Description"`
	Depth        int       `db:"depth" json:"Depth"`
	JobID        int       `db:"job_id" json:"JobID"`
	SortPosition string    `db:"sort_position" json:"SortPosition"`
	DateCreated  time.Time `db:"date_created" json:"DateCreated"`
	DateModified time.Time `db:"date_modified" json:"DateModified"`
	ULID         string    `db:"ulid" json:"ULID"`
	SiteID       int       `db:"site_id" json:"SiteID"`
	Title        string    `db:"title" json:"Title"`
}

type Milestones []*Milestone

func (h *milestoneHelper) beforeSave(record *Milestone) (err error) {
	if record.DateCreated.IsZero() {
		record.DateCreated = time.Now()
	}
	record.DateModified = time.Now()
	if record.ULID == "" {
		record.ULID = security.ULID()
	}

	validationErr := h.validate(record)
	if validationErr != nil {
		return validationErr
	}
	return err
}

func (h *milestoneHelper) afterSave(record *Milestone) (err error) {
	return err
}

// GENERATED CODE - Leave the below code alone
type milestoneHelper struct {
	DB         *runner.DB
	Cache      Cache
	fieldNames []string
	orderBy    string
}

func MilestoneHelper() *milestoneHelper {
	if milestoneHelperGlobal == nil {
		milestoneHelperGlobal = newMilestoneHelper(modelDB, modelCache)
	}
	return milestoneHelperGlobal
}

func newMilestoneHelper(db *runner.DB, cache Cache) *milestoneHelper {
	helper := &milestoneHelper{}
	helper.DB = db
	helper.Cache = cache

	// Fields
	fieldnames := []string{"milestone_id", "description", "depth", "job_id", "sort_position", "date_created", "date_modified", "ulid", "site_id", "title"}
	sort.Strings(fieldnames) // sort it makes searching it work correctly
	helper.fieldNames = fieldnames

	helper.orderBy = "date_created, date_modified"
	return helper
}

func (h *milestoneHelper) New(siteID int) *Milestone {
	record := &Milestone{}
	// check DateCreated
	record.DateCreated = time.Now()
	record.SiteID = siteID
	return record
}

func (h *milestoneHelper) FromRequest(siteID int, req *http.Request) (*Milestone, error) {
	record := h.New(siteID)
	contentType := req.Header.Get("Content-Type")
	if strings.Contains(contentType, "application/json") {
		// working with json
		decoder := json.NewDecoder(req.Body)
		err := decoder.Decode(record)
		if err != nil {
			return nil, err
		}
	} else {
		return nil, errors.New("Disabled - bring in h.structDecoder from gorilla")
		// // working with form values
		// err := req.ParseForm()
		// if err != nil {
		// 	return nil, err
		// }

		// err = h.structDecoder.Decode(record, req.PostForm)
		// if err != nil {
		// 	return nil, err
		// }
	}
	if record.SiteID != siteID {
		return nil, errors.New("*Milestone update failed. SiteID Mismatch")
	}
	record.SiteID = siteID
	return record, nil
}

func (h *milestoneHelper) Load(siteID int, id int) (*Milestone, error) {
	record, err := h.One(siteID, "milestone_id = $1", id)
	if err != nil {
		return nil, err
	}
	return record, nil
}

func (h *milestoneHelper) All(siteID int) (Milestones, error) {
	var records Milestones
	err := h.DB.Select("*").
		From("milestone").
		Where("site_id = $1", siteID).
		OrderBy(h.orderBy).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *milestoneHelper) Where(siteID int, sql string, args ...interface{}) (Milestones, error) {
	var records Milestones
	sql, args = appendSiteID(siteID, sql, args...)
	err := h.DB.Select("*").
		From("milestone").
		Where(sql, args...).
		OrderBy(h.orderBy).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *milestoneHelper) SQL(siteID int, sql string, args ...interface{}) (Milestones, error) {
	if !strings.Contains(sql, "$SITEID") {
		return nil, errors.New("No $SITEID placeholder defined")
	}
	var records Milestones
	sql, args = appendSiteID(siteID, sql, args...)
	err := h.DB.SQL(sql, args...).
		QueryStructs(&records)
	if err != nil {
		return nil, err
	}

	return records, nil
}

func (h *milestoneHelper) One(siteID int, sql string, args ...interface{}) (*Milestone, error) {
	var record Milestone
	sql, args = appendSiteID(siteID, sql, args...)

	err := h.DB.Select("*").
		From("milestone").
		Where(sql, args...).
		OrderBy(h.orderBy).
		Limit(1).
		QueryStruct(&record)

	if err != nil {
		return nil, err
	}

	return &record, nil
}

func (h *milestoneHelper) Paged(siteID int, pageNum int, itemsPerPage int) (*PagedData, error) {
	pd, err := h.PagedBy(siteID, pageNum, itemsPerPage, "date_created", "") // date_created should be the most consistant because it doesn't change
	if err != nil {
		return nil, err
	}
	return pd, nil
}

func (h *milestoneHelper) PagedBy(siteID int, pageNum int, itemsPerPage int, orderByFieldName string, direction string) (*PagedData, error) {
	if orderByFieldName == "" || orderByFieldName == "default" {
		// we only want the first field name
		orderByFieldName = strings.Split(h.orderBy, ",")[0]
		orderByFieldName = strings.Trim(orderByFieldName, " ")
	}
	i := sort.SearchStrings(h.fieldNames, orderByFieldName)
	// check the orderby exists within the fields as this could be an easy sql injection hole.
	if !(i < len(h.fieldNames) && h.fieldNames[i] == orderByFieldName) { // NOT
		return nil, errors.New("field name [" + orderByFieldName + "]  isn't a valid field name")
	}

	if !(direction == "asc" || direction == "desc" || direction == "") {
		return nil, errors.New("direction isn't valid")
	}

	var records Milestones
	err := h.DB.Select("*").
		From("milestone").
		Where("site_id = $1", siteID).
		OrderBy(orderByFieldName + " " + direction).
		Offset(uint64((pageNum - 1) * itemsPerPage)).
		Limit(uint64(itemsPerPage)).
		QueryStructs(&records)

	if err != nil {
		return nil, err
	}

	count := 0
	h.DB.SQL(`select count(milestone_id) from milestone where site_id = $1`, siteID).QueryStruct(&count)
	return NewPagedData(records, orderByFieldName, direction, itemsPerPage, pageNum, count), nil
}

func (h *milestoneHelper) Save(siteID int, record *Milestone) error {
	return h.save(siteID, record)
}

func (h *milestoneHelper) SaveMany(siteID int, records Milestones) error {
	for _, record := range records {
		err := h.save(siteID, record)
		if err != nil {
			return err
		}
	}

	return nil
}

func (h *milestoneHelper) save(siteID int, record *Milestone) error {
	err := h.beforeSave(record)
	if err != nil {
		return err
	}

	if record.SiteID != siteID {
		return errors.New("*Milestone update failed. SiteID Mismatch")
	}
	cols := []string{"description", "depth", "job_id", "sort_position", "date_created", "date_modified", "ulid", "site_id", "title"}
	vals := []interface{}{record.Description, record.Depth, record.JobID, record.SortPosition, record.DateCreated, record.DateModified, record.ULID, record.SiteID, record.Title}
	if record.MilestoneID > 0 {
		// UPDATE
		b := h.DB.Update("milestone")
		for i := range cols {
			b.Set(cols[i], vals[i])
		}
		b.Where("milestone_id = $1", record.MilestoneID)
		b.Returning("milestone_id")
		err = b.QueryStruct(record)
	} else {
		// INSERT
		err = h.DB.
			InsertInto("milestone").
			Columns(cols...).
			Values(vals...).
			Returning("milestone_id").
			QueryStruct(record)
	}
	if err != nil {
		return err
	}
	err = h.afterSave(record)
	return err
}

func (h *milestoneHelper) Delete(siteID int, recordID int) (bool, error) {
	result, err := h.DB.
		DeleteFrom("milestone").
		Where("site_id=$1 and milestone_id=$2", siteID, recordID).
		Exec()

	if err != nil {
		return false, err
	}

	return (result.RowsAffected > 0), nil
}

func (h *milestoneHelper) validate(record *Milestone) (err error) {
	return nil
	//	validationErrors := h.validator.Struct(record)
	//	if validationErrors != nil {
	//		errMessage := ""
	//		for _, err := range err.(validator.ValidationErrors) {
	//			errMessage += err.Kind().String() + " validation Error on field "+err.Field()
	//		}
	//		if errMessage != "" {
	//			err = errors.New(errMessage)
	//		}
	//	}
	//	return err
}
